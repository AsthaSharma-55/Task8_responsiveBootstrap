import React from "react";

const Footer = () => {
    return (
        <>
            <div className="row m-0 p-0">


                <div className="col-xs-12 bg-dark col-sm-12 col-md-12 col-lg-12">
                    <div className="container-fluid" style={{ color: "white", backgroundColor: "black", height: "282px" }}>
                        <h4 style={{ textAlign: "center", padding: "113px" }}>Footer</h4>
                    </div>
                </div>



            </div>
            {/* <div>
                <div className="container-fluid" style={{color: "white",backgroundColor: "black",height: "264px"}}>
                        <h4 style={{textAlign:"center",padding:"113px"}}>Footer</h4>
                </div>
            </div> */}

        </>
    )
}
export default Footer;