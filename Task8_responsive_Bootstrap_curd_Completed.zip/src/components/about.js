import React from "react";
import Layout from "./layout/layout";
import Filter from "./Filter";

const About=()=>{
    return(
        <Filter>
      
        <div>
           <h1>About</h1> 
        </div>
        
        </Filter>
        
       
    )
}
export default About;