import React from "react";

import Filter from "./Filter";

const Profile=()=>{
    return(
        <Filter>
      
        <div>
           <h1>ProfilePage</h1> 
        </div>
        
        </Filter>
        
       
    )
}
export default Profile;